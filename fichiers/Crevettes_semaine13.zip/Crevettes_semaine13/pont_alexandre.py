import requests
from bs4 import BeautifulSoup
import psycopg2
from datetime import datetime
import locale

locale.setlocale(locale.LC_TIME, "fr_FR.UTF-8")
conn = psycopg2.connect(
    dbname="jo2024",
    user="postgres",
    password="os27!Man06",
    host=""
)

# Création d'un curseur pour exécuter des requêtes SQL
cur = conn.cursor()

id_site = ""
nom_site=""
date_construction="1 janvier "
adresse_site=""
ville_site=""
code_postal_site=00000
capacite_site= -1
site_web_site=""
# URL de la page Wikipedia
url = "https://fr.wikipedia.org/wiki/Pont_Alexandre-III"
site_web_site= url
# Obtenir le contenu de la page
response = requests.get(url)
soup = BeautifulSoup(response.text, 'html.parser')

# Trouver la div avec la classe "infobox_v3 noarchive large"
table_infobox = soup.find('table', class_='infobox_v2 noarchive')
magic_box = []
# Si la div est trouvée, accéder à la première table à l'intérieur
if table_infobox:
    # Accéder au premier tbody à l'intérieur de la table
    tbody = table_infobox.find('tbody')
    
    # Si le tbody est trouvé
    if tbody:
        # Parcourir chaque tr à l'intérieur du tbody
        for tr in tbody.find_all('tr'):
            # Récupérer le contenu de chaque td dans le tr
            tds = tr.find_all('td')
            for td in tds:
                # Afficher le contenu du td
                magic_box.append(td.text.strip())
            
nom_site = magic_box[0]
date_construction += magic_box[13]
ville_site = magic_box[4]
adresse_site = magic_box[7]
print(magic_box)

magic_box3=[]
if table_infobox:
    # Trouver toutes les balises <table> à l'intérieur de la balise <div>
    tables = table_infobox.find_all('tbody')
    
    # Vérifier s'il y a au moins deux tables
        # Accéder à la deuxième table
    second_table = tables[0]
        
        # Trouver le deuxième tr de la deuxième table
    second_tr = second_table.find_all('tr')[5]  # Index 1 pour le deuxième tr
        
        # Trouver le deuxième td du deuxième tr
    second_td = second_tr.find_all('td')[0]  
        
        # Récupérer les informations textuelles dans le deuxième td
    for item in second_td.stripped_strings:
            # Ajouter l'information textuelle à magic_box2
        magic_box3.append(item)

print(magic_box3)






id_site = 24


print(id_site)
print(nom_site)
print(date_construction)
print(adresse_site)
print(ville_site)
print(code_postal_site)
print(capacite_site)
print(site_web_site)

'''capacite_site = capacite_site.replace("\xa0", " ")
capacite_site = int(capacite_site.replace(" ", ""))'''
date_construction = datetime.strptime(date_construction,"%d %B %Y").date()
date_construction = date_construction.strftime("%Y-%m-%d")

cur.execute("""
    INSERT INTO Site (id_site,nom_site, date_construction, adresse_site, ville_site, code_postal_site, capacite_site, site_web_site)
    VALUES (%s,%s, %s, %s, %s, %s, %s, %s)
""", (id_site,nom_site, date_construction, adresse_site, ville_site, code_postal_site, capacite_site, site_web_site))

# Valider la transaction
conn.commit()

# Fermer le curseur et la connexion
cur.close()
conn.close()






