import requests
from bs4 import BeautifulSoup
import psycopg2
from datetime import datetime
import locale

locale.setlocale(locale.LC_TIME, "fr_FR.UTF-8")
conn = psycopg2.connect(
    dbname="jo2024",
    user="postgres",
    password="os27!Man06",
    host=""
)

# Création d'un curseur pour exécuter des requêtes SQL
cur = conn.cursor()

id_site = ""
nom_site=""
date_construction=""
adresse_site=""
ville_site=""
code_postal_site=00000
capacite_site= -1
site_web_site=""
# URL de la page Wikipedia
url = "https://fr.wikipedia.org/wiki/Grand_Palais_%C3%A9ph%C3%A9m%C3%A8re"
site_web_site= url
# Obtenir le contenu de la page
response = requests.get(url)
soup = BeautifulSoup(response.text, 'html.parser')

# Trouver la div avec la classe "infobox_v3 noarchive large"
infobox_div = soup.find('div', class_='infobox_v3 noarchive large')
magic_box = []
# Si la div est trouvée, accéder à la première table à l'intérieur
if infobox_div:
    # Trouver toutes les balises <table> à l'intérieur de la balise <div>
    tables = infobox_div.find_all('table')
    
    # Vérifier s'il y a au moins deux tables
    if len(tables) >= 2:
        # Accéder à la deuxième table
        second_table = tables[1]
        
        # Trouver le deuxième tr de la deuxième table
        second_tr = second_table.find_all('tr')[1]  # Index 1 pour le deuxième tr
        
        # Trouver le deuxième td du deuxième tr
        second_td = second_tr.find_all('td')[0]  
        
        # Récupérer les informations textuelles dans le deuxième td
        for item in second_td.stripped_strings:
            # Ajouter l'information textuelle à magic_box2
            magic_box.append(item)

ville_site = magic_box[0]

magic_box2 = []
# Si la div est trouvée, accéder à la première table à l'intérieur
if infobox_div:
    # Trouver toutes les balises <table> à l'intérieur de la balise <div>
    tables = infobox_div.find_all('table')
    
    # Vérifier s'il y a au moins deux tables
    if len(tables) >= 2:
        # Accéder à la deuxième table
        second_table = tables[1]
        
        # Trouver le deuxième tr de la deuxième table
        second_tr = second_table.find_all('tr')[2]  # Index 1 pour le deuxième tr
        
        # Trouver le deuxième td du deuxième tr
        second_td = second_tr.find_all('td')[0]  
        
        # Récupérer les informations textuelles dans le deuxième td
        for item in second_td.stripped_strings:
            # Ajouter l'information textuelle à magic_box2
            adresse_site = item




entete_div = soup.find('div', class_='entete')


third_div = entete_div

# Extraire le texte de la troisième div sans les balises
nom_site = third_div.get_text(strip=True)
time_tag = soup.find('time', class_='nowrap')

time_tag = soup.find('time', class_='nowrap')

# Si la balise time est trouvée, récupérer son contenu textuel
if time_tag:
    date_construction = time_tag.text.strip()
    


id_site = 15



print(id_site)
print(nom_site)
print(date_construction)
print(adresse_site)
print(ville_site)
print(code_postal_site)
print(capacite_site)
print(site_web_site)

"""capacite_site = capacite_site.replace("\xa0", " ")"""
date_construction = datetime.strptime(date_construction,"%d %B %Y").date()
date_construction = date_construction.strftime("%Y-%m-%d")

cur.execute("""
    INSERT INTO Site (id_site,nom_site, date_construction, adresse_site, ville_site, code_postal_site, capacite_site, site_web_site)
    VALUES (%s,%s, %s, %s, %s, %s, %s, %s)
""", (id_site,nom_site, date_construction, adresse_site, ville_site, code_postal_site, capacite_site, site_web_site))

# Valider la transaction
conn.commit()

# Fermer le curseur et la connexion
cur.close()
conn.close()





