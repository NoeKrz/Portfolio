import csv


fichier_csv = "arrets_train.csv"
liste_train = []

valeurs_uniques3 = set()

with open(fichier_csv, newline='') as csvfile:
    lecteur_csv = csv.reader(csvfile, delimiter=';')  


    next(lecteur_csv)

    for ligne in lecteur_csv:

        derniere_valeur = ligne[10]
        nom_arret = ligne[4]
        valeurs_uniques3.add((nom_arret,derniere_valeur))


for valeur in valeurs_uniques3:
    liste_train.append(valeur)

print(liste_train)
