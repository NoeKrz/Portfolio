import requests
from bs4 import BeautifulSoup
import psycopg2
from datetime import datetime
import locale

locale.setlocale(locale.LC_TIME, "fr_FR.UTF-8")
conn = psycopg2.connect(
    dbname="jo2024",
    user="postgres",
    password="os27!Man06",
    host=""
)

# Création d'un curseur pour exécuter des requêtes SQL
cur = conn.cursor()

id_site = ""
nom_site=""
date_construction="1 janvier "
adresse_site=""
ville_site=""
code_postal_site=00000
capacite_site= -1
site_web_site=""
# URL de la page Wikipedia
url = "https://www.paris2024.org/fr/site/arena-paris-sud/"
site_web_site= url
# Obtenir le contenu de la page
response = requests.get(url)
soup = BeautifulSoup(response.text, 'html.parser')

# Trouver l'élément h1 avec la classe "title-1"
h1_element = soup.find('h1', class_='title-1')


# Vérifier si l'élément h1 existe
if h1_element:
    # Extraire le texte de l'élément h1
    nom_site = h1_element.text.strip()

magic_box = []
divs_with_class = soup.find_all('div', class_='block-classic-editor')
for div in divs_with_class:
    # Trouver tous les éléments enfants de la balise div
    children = div.find_all(recursive=False)
    
    # Ajouter le contenu de chaque élément à la liste elements_list
    for child in children:
        magic_box.append(str(child))


print(magic_box[1:])
a = magic_box[0].split()
ville_site = magic_box[20].split()[2][:-1]
a = magic_box[4].split()
date_construction += magic_box[1].split()[2]
print(magic_box[5])
print( magic_box[5].split())
capacite_site= magic_box[5].split()[2]
capacite_site= capacite_site.split(',')
capacite_site= " ".join(capacite_site)


id_site = 31
print(id_site)
print(nom_site)
print(date_construction)
print(adresse_site)
print(ville_site)
print(code_postal_site)
print(capacite_site)
print(site_web_site)


capacite_site = capacite_site.replace("\xa0", " ")
capacite_site = int(capacite_site.replace(" ", ""))
date_construction = datetime.strptime(date_construction, "%d %B %Y").date()
date_construction = date_construction.strftime("%Y-%m-%d")

cur.execute("""
    INSERT INTO Site (id_site,nom_site, date_construction, adresse_site, ville_site, code_postal_site, capacite_site, site_web_site)
    VALUES (%s,%s, %s, %s, %s, %s, %s, %s)
""", (id_site,nom_site, date_construction, adresse_site, ville_site, code_postal_site, capacite_site, site_web_site))

# Valider la transaction
conn.commit()

# Fermer le curseur et la connexion
cur.close()
conn.close()







