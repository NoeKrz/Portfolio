import csv


fichier_csv = "arret_metro.csv"
liste_metro = []

valeurs_uniques = set()

with open(fichier_csv, newline='') as csvfile:
    lecteur_csv = csv.reader(csvfile, delimiter=';')  


    next(lecteur_csv)

    for ligne in lecteur_csv:

        derniere_valeur = ligne[10]
        nom_arret = ligne[4]
        valeurs_uniques.add((nom_arret,derniere_valeur))


for valeur in valeurs_uniques:
    liste_metro.append(valeur)
